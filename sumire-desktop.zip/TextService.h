//////////////////////////////////////////////////////////////////////
//
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
//  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED
//  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
//  PARTICULAR PURPOSE.
//
//  TextService.h
//
//          CTextService declaration.
//
//////////////////////////////////////////////////////////////////////

#ifndef TEXTSERVICE_H
#define TEXTSERVICE_H

#include <msctf.h>
#include "ComposingText.h"
#include "RomajiKanaConverter.h"

class CLangBarItemButton;
class CCandidateList;

// ���̓��[�h�̒�`�i�� / ENG �p�j
enum InputMode
{
    INPUTMODE_HIRAGANA = 0,      // ���[�}�����Ђ炪��
    INPUTMODE_ALPHANUMERIC = 1   // ���̂܂܉p�����iENG�j
};

class CTextService : public ITfTextInputProcessorEx,
    public ITfThreadMgrEventSink,
    public ITfTextEditSink,
    public ITfKeyEventSink,
    public ITfCompositionSink,
    public ITfDisplayAttributeProvider
{
public:
    CTextService();
    ~CTextService();

    // IUnknown
    STDMETHODIMP QueryInterface(REFIID riid, void** ppvObj);
    STDMETHODIMP_(ULONG) AddRef(void);
    STDMETHODIMP_(ULONG) Release(void);

    // ITfTextInputProcessor
    STDMETHODIMP Activate(ITfThreadMgr* pThreadMgr, TfClientId tfClientId);
    STDMETHODIMP Deactivate();

    // ITfTextInputProcessorEx
    STDMETHODIMP ActivateEx(ITfThreadMgr* pThreadMgr, TfClientId tfClientId, DWORD dwFlags);

    // ITfThreadMgrEventSink
    STDMETHODIMP OnInitDocumentMgr(ITfDocumentMgr* pDocMgr);
    STDMETHODIMP OnUninitDocumentMgr(ITfDocumentMgr* pDocMgr);
    STDMETHODIMP OnSetFocus(ITfDocumentMgr* pDocMgrFocus, ITfDocumentMgr* pDocMgrPrevFocus);
    STDMETHODIMP OnPushContext(ITfContext* pContext);
    STDMETHODIMP OnPopContext(ITfContext* pContext);

    // ITfTextEditSink
    STDMETHODIMP OnEndEdit(ITfContext* pContext, TfEditCookie ecReadOnly, ITfEditRecord* pEditRecord);

    // ITfKeyEventSink
    STDMETHODIMP OnSetFocus(BOOL fForeground);
    STDMETHODIMP OnTestKeyDown(ITfContext* pContext, WPARAM wParam, LPARAM lParam, BOOL* pfEaten);
    STDMETHODIMP OnKeyDown(ITfContext* pContext, WPARAM wParam, LPARAM lParam, BOOL* pfEaten);
    STDMETHODIMP OnTestKeyUp(ITfContext* pContext, WPARAM wParam, LPARAM lParam, BOOL* pfEaten);
    STDMETHODIMP OnKeyUp(ITfContext* pContext, WPARAM wParam, LPARAM lParam, BOOL* pfEaten);
    STDMETHODIMP OnPreservedKey(ITfContext* pContext, REFGUID rguid, BOOL* pfEaten);

    // ITfCompositionSink
    STDMETHODIMP OnCompositionTerminated(TfEditCookie ecWrite, ITfComposition* pComposition);

    // ITfDisplayAttributeProvider
    STDMETHODIMP EnumDisplayAttributeInfo(IEnumTfDisplayAttributeInfo** ppEnum);
    STDMETHODIMP GetDisplayAttributeInfo(REFGUID guidInfo, ITfDisplayAttributeInfo** ppInfo);

    // CClassFactory factory callback
    static HRESULT CreateInstance(IUnknown* pUnkOuter, REFIID riid, void** ppvObj);

    ITfThreadMgr* _GetThreadMgr() { return _pThreadMgr; }
    TfClientId    _GetClientId() { return _tfClientId; }
    ITfComposition* _GetComposition() { return _pComposition; }
    CCandidateList* _GetCandidateList() { return _pCandidateList; }

    // utility function for compartment
    BOOL    _IsKeyboardDisabled();
    BOOL    _IsKeyboardOpen();
    HRESULT _SetKeyboardOpen(BOOL fOpen);

    // �� LanguageBar ������g���R���p�[�g�����g�X�V�w���p�[�ipublic �ɂ���j��
    HRESULT _SetCompartment(REFGUID rguid, const VARIANT* pvar);

    // functions for the composition object.
    void _StartComposition(ITfContext* pContext);
    void _EndComposition(ITfContext* pContext);
    void _TerminateComposition(TfEditCookie ec, ITfContext* pContext);
    BOOL _IsComposing();
    void _SetComposition(ITfComposition* pComposition);

    // key event handlers.
    HRESULT _HandleCharacterKey(TfEditCookie ec, ITfContext* pContext, WPARAM wParam);
    HRESULT _HandleArrowKey(TfEditCookie ec, ITfContext* pContext, WPARAM wParam);
    HRESULT _HandleReturnKey(TfEditCookie ec, ITfContext* pContext);
    HRESULT _HandleSpaceKey(TfEditCookie ec, ITfContext* pContext);
    HRESULT _InvokeKeyHandler(ITfContext* pContext, WPARAM wParam, LPARAM lParam);

    void  _ClearCompositionDisplayAttributes(TfEditCookie ec, ITfContext* pContext);
    BOOL  _SetCompositionDisplayAttributes(TfEditCookie ec, ITfContext* pContext, TfGuidAtom gaDisplayAttribute);
    BOOL  _InitDisplayAttributeGuidAtom();

    // ���̓��[�h�̑���
    void SetInputMode(InputMode mode);
    void ToggleInputMode()
    {
        if (_inputMode == INPUTMODE_HIRAGANA)
        {
            SetInputMode(INPUTMODE_ALPHANUMERIC);
        }
        else
        {
            SetInputMode(INPUTMODE_HIRAGANA);
        }
    }

    InputMode GetInputMode() const
    {
        return _inputMode;
    }

private:
    // initialize and uninitialize ThreadMgrEventSink.
    BOOL _InitThreadMgrEventSink();
    void _UninitThreadMgrEventSink();

    // initialize TextEditSink.
    BOOL _InitTextEditSink(ITfDocumentMgr* pDocMgr);

    // initialize and uninitialize LanguageBar Item.
    BOOL _InitLanguageBar();
    void _UninitLanguageBar();
    void _UpdateLanguageBar();

    // initialize and uninitialize KeyEventSink.
    BOOL _InitKeyEventSink();
    void _UninitKeyEventSink();

    // initialize and uninitialize PreservedKey.
    BOOL _InitPreservedKey();
    void _UninitPreservedKey();

    // utility function for KeyEventSink
    BOOL _IsKeyEaten(ITfContext* pContext, WPARAM wParam);

    //
    // state
    //
    ITfThreadMgr* _pThreadMgr;
    TfClientId    _tfClientId;

    // The cookie of ThreadMgrEventSink
    DWORD _dwThreadMgrEventSinkCookie;

    //
    // private variables for TextEditSink
    //
    ITfContext* _pTextEditSinkContext;
    DWORD       _dwTextEditSinkCookie;

    // LangBar items
    CLangBarItemButton* _pLangBarItemBrand; // �u�����h�A�C�R��
    CLangBarItemButton* _pLangBarItemMode;  // IME ���[�h�A�C�R��

    // the current composition object.
    ITfComposition* _pComposition;

    // guidatom for the display attibute.
    TfGuidAtom _gaDisplayAttributeInput;
    TfGuidAtom _gaDisplayAttributeConverted;

    // the candidate list object.
    CCandidateList* _pCandidateList;

    ComposingText       _composingText;
    RomajiKanaConverter _romajiConverter;

    // ���݂̓��̓��[�h�i�� / ENG�j
    InputMode _inputMode;

    LONG _cRef;     // COM ref count
};

#endif // TEXTSERVICE_H
