//////////////////////////////////////////////////////////////////////
//
//  LanguageBar.cpp
//
//////////////////////////////////////////////////////////////////////

#include "Globals.h"
#include "TextService.h"
#include "Resource.h"
#include "LanguageBar.h"

#define TEXTSERVICE_LANGBARITEMSINK_COOKIE 0x0fab0fab

// ���j���[ ID
#define MENUITEM_INDEX_0         0   // �Ђ炪��
#define MENUITEM_INDEX_1         1   // �p��
#define MENUITEM_INDEX_OPENCLOSE 2   // �L�[�{�[�h�L��/����

// ���j���[�\��������
static WCHAR c_szMenuItemDescription0[] = L"�Ђ炪�� (��)";
static WCHAR c_szMenuItemDescription1[] = L"�p�� (A)";
static WCHAR c_szMenuItemDescriptionOpenClose[] = L"�L�[�{�[�h�̗L�� / ����";

// Globals.cpp ���Œ�`���Ă��� GUID
extern const GUID c_guidLangBarItemButton;      // �u�����h�p
extern const GUID GUID_LBI_INPUTMODE;

//
// CLangBarItemButton
//

CLangBarItemButton::CLangBarItemButton(CTextService* pTextService, REFGUID guidItem)
{
    DllAddRef();
    _cRef = 1;

    _pTextService = pTextService;
    if (_pTextService)
    {
        _pTextService->AddRef();
    }

    _pLangBarItemSink = nullptr;

    ZeroMemory(&_LangBarItemInfo, sizeof(_LangBarItemInfo));
    _LangBarItemInfo.clsidService = c_clsidTextService;
    _LangBarItemInfo.guidItem = guidItem;

    // ���[�h�A�C�R���ic_guidLangBarItemButtonMode�j�̂Ƃ��̓{�^���A
    // ����ȊO�i�u�����h�A�C�R���j�̓��j���[�t���{�^���B
    _LangBarItemInfo.dwStyle =
        TF_LBI_STYLE_SHOWNINTRAY |
        (IsEqualGUID(guidItem, GUID_LBI_INPUTMODE)
            ? TF_LBI_STYLE_BTN_BUTTON
            : TF_LBI_STYLE_BTN_MENU);

    _LangBarItemInfo.ulSort = 0;

    // �c�[���`�b�v�ELangBar �̐���
    wcsncpy_s(_LangBarItemInfo.szDescription,
        LANGBAR_ITEM_DESC,
        _TRUNCATE);
}

CLangBarItemButton::~CLangBarItemButton()
{
    if (_pLangBarItemSink)
    {
        _pLangBarItemSink->Release();
        _pLangBarItemSink = nullptr;
    }

    if (_pTextService)
    {
        _pTextService->Release();
        _pTextService = nullptr;
    }

    DllRelease();
}

//
// IUnknown
//

STDAPI CLangBarItemButton::QueryInterface(REFIID riid, void** ppvObj)
{
    if (!ppvObj)
        return E_INVALIDARG;

    *ppvObj = nullptr;

    if (IsEqualIID(riid, IID_IUnknown) ||
        IsEqualIID(riid, IID_ITfLangBarItem) ||
        IsEqualIID(riid, IID_ITfLangBarItemButton))
    {
        *ppvObj = static_cast<ITfLangBarItemButton*>(this);
    }
    else if (IsEqualIID(riid, IID_ITfSource))
    {
        *ppvObj = static_cast<ITfSource*>(this);
    }

    if (*ppvObj)
    {
        AddRef();
        return S_OK;
    }

    return E_NOINTERFACE;
}

STDAPI_(ULONG) CLangBarItemButton::AddRef()
{
    return ++_cRef;
}

STDAPI_(ULONG) CLangBarItemButton::Release()
{
    LONG cr = --_cRef;
    assert(_cRef >= 0);

    if (_cRef == 0)
    {
        delete this;
    }

    return cr;
}

//
// ITfLangBarItem
//

STDAPI CLangBarItemButton::GetInfo(TF_LANGBARITEMINFO* pInfo)
{
    if (!pInfo) return E_INVALIDARG;
    *pInfo = _LangBarItemInfo;
    return S_OK;
}

STDAPI CLangBarItemButton::GetStatus(DWORD* pdwStatus)
{
    if (!pdwStatus) return E_INVALIDARG;
    *pdwStatus = 0;
    return S_OK;
}

STDAPI CLangBarItemButton::Show(BOOL fShow)
{
    UNREFERENCED_PARAMETER(fShow);
    return S_OK;
}

STDAPI CLangBarItemButton::GetTooltipString(BSTR* pbstrToolTip)
{
    if (!pbstrToolTip) return E_INVALIDARG;

    *pbstrToolTip = SysAllocString(LANGBAR_ITEM_DESC);
    return (*pbstrToolTip == nullptr) ? E_OUTOFMEMORY : S_OK;
}

//
// ITfLangBarItemButton
//

STDMETHODIMP CLangBarItemButton::OnClick(TfLBIClick click, POINT pt, const RECT* prcArea)
{
    UNREFERENCED_PARAMETER(prcArea);

    if (_pTextService == nullptr)
        return E_UNEXPECTED;

    // ���[�h�A�C�R���ic_guidLangBarItemButtonMode�j���ǂ���
    if (IsEqualGUID(_LangBarItemInfo.guidItem, GUID_LBI_INPUTMODE))
    {
        switch (click)
        {
        case TF_LBI_CLK_LEFT:
            // ���N���b�N�Ń��[�h�g�O�� & �L�[�{�[�h ON
            _pTextService->ToggleInputMode();
            _pTextService->_SetKeyboardOpen(TRUE);
            _Update();
            break;

        case TF_LBI_CLK_RIGHT:
        {
            // �E�N���b�N�ŊȈՃ��j���[�i�Ђ炪�� / ENG�j
            HMENU hMenu = CreatePopupMenu();
            if (hMenu)
            {
                InputMode mode = _pTextService->GetInputMode();

                InsertMenuW(hMenu, -1, MF_BYPOSITION |
                    (mode == INPUTMODE_HIRAGANA ? MF_CHECKED : 0),
                    1, L"�Ђ炪��");

                InsertMenuW(hMenu, -1, MF_BYPOSITION |
                    (mode == INPUTMODE_ALPHANUMERIC ? MF_CHECKED : 0),
                    2, L"ENG");

                UINT cmd = TrackPopupMenuEx(
                    hMenu,
                    TPM_RETURNCMD | TPM_LEFTALIGN | TPM_TOPALIGN |
                    TPM_NONOTIFY | TPM_RIGHTBUTTON,
                    pt.x, pt.y,
                    GetFocus(),
                    nullptr);

                if (cmd == 1)
                {
                    _pTextService->SetInputMode(INPUTMODE_HIRAGANA);
                }
                else if (cmd == 2)
                {
                    _pTextService->SetInputMode(INPUTMODE_ALPHANUMERIC);
                }

                DestroyMenu(hMenu);
                _Update();
            }
            break;
        }

        default:
            break;
        }
    }
    else
    {
        // �u�����h�A�C�R�����̃N���b�N�i�K�v�Ȃ�ݒ�_�C�A���O�Ȃǁj
        // ���͉������Ȃ�
    }

    return S_OK;
}

STDAPI CLangBarItemButton::InitMenu(ITfMenu* pMenu)
{
    if (!pMenu)
        return E_INVALIDARG;

    if (_pTextService == nullptr)
        return E_UNEXPECTED;

    // ���[�h�A�C�R���ȊO�i�u�����h�A�C�R���j�͂����ł̓��j���[�Ȃ�
    if (!IsEqualGUID(_LangBarItemInfo.guidItem, GUID_LBI_INPUTMODE))
    {
        return S_OK;
    }

    InputMode mode = _pTextService->GetInputMode();

    // �Ђ炪��
    DWORD dwFlagsHiragana = 0;
    if (mode == INPUTMODE_HIRAGANA)
        dwFlagsHiragana |= TF_LBMENUF_CHECKED;

    pMenu->AddMenuItem(
        MENUITEM_INDEX_0,
        dwFlagsHiragana,
        nullptr,
        nullptr,
        c_szMenuItemDescription0,
        (ULONG)wcslen(c_szMenuItemDescription0),
        nullptr);

    // �p��
    DWORD dwFlagsAlnum = 0;
    if (mode == INPUTMODE_ALPHANUMERIC)
        dwFlagsAlnum |= TF_LBMENUF_CHECKED;

    pMenu->AddMenuItem(
        MENUITEM_INDEX_1,
        dwFlagsAlnum,
        nullptr,
        nullptr,
        c_szMenuItemDescription1,
        (ULONG)wcslen(c_szMenuItemDescription1),
        nullptr);

    // �L�[�{�[�h�L��/����
    DWORD dwFlagsOpenClose = 0;
    if (_pTextService->_IsKeyboardDisabled())
        dwFlagsOpenClose |= TF_LBMENUF_GRAYED;
    else if (_pTextService->_IsKeyboardOpen())
        dwFlagsOpenClose |= TF_LBMENUF_CHECKED;

    pMenu->AddMenuItem(
        MENUITEM_INDEX_OPENCLOSE,
        dwFlagsOpenClose,
        nullptr,
        nullptr,
        c_szMenuItemDescriptionOpenClose,
        (ULONG)wcslen(c_szMenuItemDescriptionOpenClose),
        nullptr);

    return S_OK;
}

STDAPI CLangBarItemButton::OnMenuSelect(UINT wID)
{
    if (_pTextService == nullptr)
        return E_UNEXPECTED;

    if (!IsEqualGUID(_LangBarItemInfo.guidItem, GUID_LBI_INPUTMODE))
    {
        // �u�����h�A�C�R���̃��j���[��������������΂����ŏ���
        return S_OK;
    }

    switch (wID)
    {
    case MENUITEM_INDEX_0: // �Ђ炪��
        _pTextService->SetInputMode(INPUTMODE_HIRAGANA);
        break;

    case MENUITEM_INDEX_1: // �p��
        _pTextService->SetInputMode(INPUTMODE_ALPHANUMERIC);
        break;

    case MENUITEM_INDEX_OPENCLOSE:
    {
        BOOL fOpen = _pTextService->_IsKeyboardOpen();
        _pTextService->_SetKeyboardOpen(fOpen ? FALSE : TRUE);
        break;
    }

    default:
        break;
    }

    if (_pLangBarItemSink)
    {
        _pLangBarItemSink->OnUpdate(TF_LBI_ICON | TF_LBI_TEXT | TF_LBI_STATUS);
    }

    return S_OK;
}

STDMETHODIMP CLangBarItemButton::GetIcon(HICON* phIcon)
{
    if (!phIcon) return E_INVALIDARG;
    *phIcon = nullptr;

    return _GetIconInternal(phIcon);
}

HRESULT CLangBarItemButton::_GetIconInternal(HICON* phIcon)
{
    WORD idIcon = IDI_TEXTSERVICE;

    if (IsEqualGUID(_LangBarItemInfo.guidItem, GUID_LBI_INPUTMODE))
    {
        // ���[�h�A�C�R��
        if (_pTextService && _pTextService->GetInputMode() == INPUTMODE_HIRAGANA)
            idIcon = IDI_MODE_HIRAGANA;
        else
            idIcon = IDI_MODE_ALPHANUMERIC;
    }
    else
    {
        // �u�����h�A�C�R��
        idIcon = IDI_TEXTSERVICE;
    }

    *phIcon = (HICON)LoadImageW(
        g_hInst,
        MAKEINTRESOURCEW(idIcon),
        IMAGE_ICON,
        0, 0,
        LR_DEFAULTSIZE | LR_SHARED);

    return (*phIcon != nullptr) ? S_OK : E_FAIL;
}

STDAPI CLangBarItemButton::GetText(BSTR* pbstrText)
{
    if (!pbstrText)
        return E_INVALIDARG;

    const WCHAR* pszText = nullptr;

    if (_pTextService != nullptr &&
        IsEqualGUID(_LangBarItemInfo.guidItem, GUID_LBI_INPUTMODE))
    {
        // ���[�h�A�C�R���̃e�L�X�g
        InputMode mode = _pTextService->GetInputMode();
        pszText = (mode == INPUTMODE_HIRAGANA) ? L"��" : L"A";
    }
    else
    {
        // �u�����h�A�C�R�� or TextService ���ڑ�
        pszText = LANGBAR_ITEM_DESC;
    }

    *pbstrText = SysAllocString(pszText);
    return (*pbstrText == nullptr) ? E_OUTOFMEMORY : S_OK;
}

//
// ITfSource
//

STDAPI CLangBarItemButton::AdviseSink(REFIID riid, IUnknown* punk, DWORD* pdwCookie)
{
    if (!IsEqualIID(IID_ITfLangBarItemSink, riid))
        return CONNECT_E_CANNOTCONNECT;

    if (_pLangBarItemSink != nullptr)
        return CONNECT_E_ADVISELIMIT;

    if (punk->QueryInterface(IID_ITfLangBarItemSink, (void**)&_pLangBarItemSink) != S_OK)
    {
        _pLangBarItemSink = nullptr;
        return E_NOINTERFACE;
    }

    *pdwCookie = TEXTSERVICE_LANGBARITEMSINK_COOKIE;
    return S_OK;
}

STDAPI CLangBarItemButton::UnadviseSink(DWORD dwCookie)
{
    if (dwCookie != TEXTSERVICE_LANGBARITEMSINK_COOKIE)
        return CONNECT_E_NOCONNECTION;

    if (_pLangBarItemSink == nullptr)
        return CONNECT_E_NOCONNECTION;

    _pLangBarItemSink->Release();
    _pLangBarItemSink = nullptr;

    return S_OK;
}

HRESULT CLangBarItemButton::_Update()
{
    if (_pTextService == nullptr)
        return E_FAIL;

    VARIANT var;
    VariantInit(&var);

    // ���߃��[�h�i�K�v�Ȃ���΍폜�j
    V_VT(&var) = VT_I4;
    V_I4(&var) = TF_SENTENCEMODE_PHRASEPREDICT;
    _pTextService->_SetCompartment(
        GUID_COMPARTMENT_KEYBOARD_INPUTMODE_SENTENCE, &var);

    // �ϊ����[�h�i�Ђ炪�� / ENG�j
    if (!_pTextService->_IsKeyboardDisabled() && _pTextService->_IsKeyboardOpen())
    {
        InputMode mode = _pTextService->GetInputMode();

        if (mode == INPUTMODE_HIRAGANA)
        {
            V_I4(&var) = TF_CONVERSIONMODE_NATIVE |
                TF_CONVERSIONMODE_FULLSHAPE |
                TF_CONVERSIONMODE_ROMAN;
        }
        else
        {
            V_I4(&var) = TF_CONVERSIONMODE_ALPHANUMERIC;
        }

        _pTextService->_SetCompartment(
            GUID_COMPARTMENT_KEYBOARD_INPUTMODE_CONVERSION, &var);
    }

    if (_pLangBarItemSink == nullptr)
        return E_FAIL;

    return _pLangBarItemSink->OnUpdate(TF_LBI_ICON | TF_LBI_TEXT | TF_LBI_STATUS);
}
