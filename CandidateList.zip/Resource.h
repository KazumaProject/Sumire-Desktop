//////////////////////////////////////////////////////////////////////
//
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
//  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED
//  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
//  PARTICULAR PURPOSE.
//
//  Resource.h
//
//          Resource declarations.
//
//////////////////////////////////////////////////////////////////////

#ifndef RESOURCE_H
#define RESOURCE_H

//
// String resources
//
#define IDS_TEXTSERVICE            1
#define IDS_DISPLAY_NAME           2
#define IDS_TRUE                   3
#define IDS_FALSE                  4

//
// Icon resources
//
#define IDI_TEXTSERVICE           101   // �����̃e�L�X�g�T�[�r�X���ʃA�C�R��
#define IDI_MODE_HIRAGANA         201   // �u���v���[�h�p�A�C�R��
#define IDI_MODE_ALPHANUMERIC     202   // �uA�v���[�h�p�A�C�R��

#endif // RESOURCE_H
