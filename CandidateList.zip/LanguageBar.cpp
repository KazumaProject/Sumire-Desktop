//////////////////////////////////////////////////////////////////////
//
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
//  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED
//  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
//  PARTICULAR PURPOSE.
//
//  Copyright (C) 2003  Microsoft Corporation.  All rights reserved.
//
//  LanguageBar.cpp
//
//          Language Bar UI code.
//
//////////////////////////////////////////////////////////////////////

#include "Globals.h"
#include "TextService.h"
#include "Resource.h"

//
// The cookie for the sink to CLangBarItemButton.
//
#define TEXTSERVICE_LANGBARITEMSINK_COOKIE 0x0fab0fab

//
// The ids of the menu item of the language bar button.
//
#define MENUITEM_INDEX_0        0   // �Ђ炪��
#define MENUITEM_INDEX_1        1   // �p��
#define MENUITEM_INDEX_OPENCLOSE 2  // �L�[�{�[�h�L��/����

//
// The descriptions of the menu item of the language bar button.
//
static WCHAR c_szMenuItemDescription0[] = L"�Ђ炪�� (��)";
static WCHAR c_szMenuItemDescription1[] = L"�p�� (A)";
static WCHAR c_szMenuItemDescriptionOpenClose[] = L"�L�[�{�[�h�̗L�� / ����";

//+---------------------------------------------------------------------------
//
// CLangBarItemButton class
//
//----------------------------------------------------------------------------

class CLangBarItemButton : public ITfLangBarItemButton,
    public ITfSource
{
public:
    CLangBarItemButton(CTextService* pTextService);
    ~CLangBarItemButton();

    // IUnknown
    STDMETHODIMP QueryInterface(REFIID riid, void** ppvObj);
    STDMETHODIMP_(ULONG) AddRef(void);
    STDMETHODIMP_(ULONG) Release(void);

    // ITfLangBarItem
    STDMETHODIMP GetInfo(TF_LANGBARITEMINFO* pInfo);
    STDMETHODIMP GetStatus(DWORD* pdwStatus);
    STDMETHODIMP Show(BOOL fShow);
    STDMETHODIMP GetTooltipString(BSTR* pbstrToolTip);

    // ITfLangBarItemButton
    STDMETHODIMP OnClick(TfLBIClick click, POINT pt, const RECT* prcArea);
    STDMETHODIMP InitMenu(ITfMenu* pMenu);
    STDMETHODIMP OnMenuSelect(UINT wID);
    STDMETHODIMP GetIcon(HICON* phIcon);
    STDMETHODIMP GetText(BSTR* pbstrText);

    // ITfSource
    STDMETHODIMP AdviseSink(REFIID riid, IUnknown* punk, DWORD* pdwCookie);
    STDMETHODIMP UnadviseSink(DWORD dwCookie);

private:
    ITfLangBarItemSink* _pLangBarItemSink;
    TF_LANGBARITEMINFO _tfLangBarItemInfo;

    CTextService* _pTextService;
    LONG _cRef;
};

//+---------------------------------------------------------------------------
//
// ctor
//
//----------------------------------------------------------------------------

CLangBarItemButton::CLangBarItemButton(CTextService* pTextService)
{
    DllAddRef();

    //
    // initialize TF_LANGBARITEMINFO structure.
    //
    _tfLangBarItemInfo.clsidService = c_clsidTextService;    // This LangBarItem belongs to this TextService.
    _tfLangBarItemInfo.guidItem = c_guidLangBarItemButton; // GUID_LBI_INPUTMODE �Ƃ��Đ錾�ς�
    _tfLangBarItemInfo.dwStyle = TF_LBI_STYLE_BTN_MENU | TF_LBI_STYLE_SHOWNINTRAY;
    _tfLangBarItemInfo.ulSort = 0;
    StringCchCopy(_tfLangBarItemInfo.szDescription,
        ARRAYSIZE(_tfLangBarItemInfo.szDescription),
        LANGBAR_ITEM_DESC);

    // Initialize the sink pointer to NULL.
    _pLangBarItemSink = NULL;

    _pTextService = pTextService;
    _pTextService->AddRef();

    _cRef = 1;
}

//+---------------------------------------------------------------------------
//
// dtor
//
//----------------------------------------------------------------------------

CLangBarItemButton::~CLangBarItemButton()
{
    DllRelease();
    _pTextService->Release();
}

//+---------------------------------------------------------------------------
//
// QueryInterface
//
//----------------------------------------------------------------------------

STDAPI CLangBarItemButton::QueryInterface(REFIID riid, void** ppvObj)
{
    if (ppvObj == NULL)
        return E_INVALIDARG;

    *ppvObj = NULL;

    if (IsEqualIID(riid, IID_IUnknown) ||
        IsEqualIID(riid, IID_ITfLangBarItem) ||
        IsEqualIID(riid, IID_ITfLangBarItemButton))
    {
        *ppvObj = (ITfLangBarItemButton*)this;
    }
    else if (IsEqualIID(riid, IID_ITfSource))
    {
        *ppvObj = (ITfSource*)this;
    }

    if (*ppvObj)
    {
        AddRef();
        return S_OK;
    }

    return E_NOINTERFACE;
}

//+---------------------------------------------------------------------------
//
// AddRef
//
//----------------------------------------------------------------------------

STDAPI_(ULONG) CLangBarItemButton::AddRef()
{
    return ++_cRef;
}

//+---------------------------------------------------------------------------
//
// Release
//
//----------------------------------------------------------------------------

STDAPI_(ULONG) CLangBarItemButton::Release()
{
    LONG cr = --_cRef;

    assert(_cRef >= 0);

    if (_cRef == 0)
    {
        delete this;
    }

    return cr;
}

//+---------------------------------------------------------------------------
//
// GetInfo
//
//----------------------------------------------------------------------------

STDAPI CLangBarItemButton::GetInfo(TF_LANGBARITEMINFO* pInfo)
{
    *pInfo = _tfLangBarItemInfo;
    return S_OK;
}

//+---------------------------------------------------------------------------
//
// GetStatus
//
//----------------------------------------------------------------------------

STDAPI CLangBarItemButton::GetStatus(DWORD* pdwStatus)
{
    *pdwStatus = 0;
    return S_OK;
}

//+---------------------------------------------------------------------------
//
// Show
//
//----------------------------------------------------------------------------

STDAPI CLangBarItemButton::Show(BOOL fShow)
{
    UNREFERENCED_PARAMETER(fShow);
    return E_NOTIMPL;
}

//+---------------------------------------------------------------------------
//
// GetTooltipString
//
//----------------------------------------------------------------------------

STDAPI CLangBarItemButton::GetTooltipString(BSTR* pbstrToolTip)
{
    *pbstrToolTip = SysAllocString(LANGBAR_ITEM_DESC);

    return (*pbstrToolTip == NULL) ? E_OUTOFMEMORY : S_OK;
}

//+---------------------------------------------------------------------------
//
// OnClick
//
//----------------------------------------------------------------------------

STDAPI CLangBarItemButton::OnClick(TfLBIClick click, POINT pt, const RECT* prcArea)
{
    UNREFERENCED_PARAMETER(pt);
    UNREFERENCED_PARAMETER(prcArea);

    if (_pTextService == NULL)
        return E_UNEXPECTED;

    // ���N���b�N�Łu�� / A�v�g�O��
    if (click == TF_LBI_CLK_LEFT)
    {
        _pTextService->ToggleInputMode();

        // �A�C�R�� / �e�L�X�g�X�V�ʒm
        if (_pLangBarItemSink)
        {
            _pLangBarItemSink->OnUpdate(TF_LBI_ICON | TF_LBI_TEXT | TF_LBI_STATUS);
        }
    }

    return S_OK;
}

//+---------------------------------------------------------------------------
//
// InitMenu
//
//----------------------------------------------------------------------------

STDAPI CLangBarItemButton::InitMenu(ITfMenu* pMenu)
{
    if (pMenu == NULL)
        return E_INVALIDARG;

    InputMode mode = _pTextService->GetInputMode();

    //
    // �Ђ炪�ȃ��j���[����
    //
    DWORD dwFlagsHiragana = 0;
    if (mode == INPUTMODE_HIRAGANA)
    {
        dwFlagsHiragana |= TF_LBMENUF_CHECKED;
    }

    pMenu->AddMenuItem(MENUITEM_INDEX_0,
        dwFlagsHiragana,
        NULL,
        NULL,
        c_szMenuItemDescription0,
        (ULONG)wcslen(c_szMenuItemDescription0),
        NULL);

    //
    // �p�����j���[����
    //
    DWORD dwFlagsAlnum = 0;
    if (mode == INPUTMODE_ALPHANUMERIC)
    {
        dwFlagsAlnum |= TF_LBMENUF_CHECKED;
    }

    pMenu->AddMenuItem(MENUITEM_INDEX_1,
        dwFlagsAlnum,
        NULL,
        NULL,
        c_szMenuItemDescription1,
        (ULONG)wcslen(c_szMenuItemDescription1),
        NULL);

    //
    // �L�[�{�[�h�L���^����
    //
    DWORD dwFlagsOpenClose = 0;
    if (_pTextService->_IsKeyboardDisabled())
        dwFlagsOpenClose |= TF_LBMENUF_GRAYED;
    else if (_pTextService->_IsKeyboardOpen())
        dwFlagsOpenClose |= TF_LBMENUF_CHECKED;

    pMenu->AddMenuItem(MENUITEM_INDEX_OPENCLOSE,
        dwFlagsOpenClose,
        NULL,
        NULL,
        c_szMenuItemDescriptionOpenClose,
        (ULONG)wcslen(c_szMenuItemDescriptionOpenClose),
        NULL);

    return S_OK;
}

//+---------------------------------------------------------------------------
//
// OnMenuSelect
//
//----------------------------------------------------------------------------

STDAPI CLangBarItemButton::OnMenuSelect(UINT wID)
{
    if (_pTextService == NULL)
        return E_UNEXPECTED;

    switch (wID)
    {
    case MENUITEM_INDEX_0:
        // �Ђ炪��
        _pTextService->SetInputMode(INPUTMODE_HIRAGANA);
        break;

    case MENUITEM_INDEX_1:
        // �p��
        _pTextService->SetInputMode(INPUTMODE_ALPHANUMERIC);
        break;

    case MENUITEM_INDEX_OPENCLOSE:
    {
        BOOL fOpen = _pTextService->_IsKeyboardOpen();
        _pTextService->_SetKeyboardOpen(fOpen ? FALSE : TRUE);
        break;
    }

    default:
        break;
    }

    if (_pLangBarItemSink)
    {
        _pLangBarItemSink->OnUpdate(TF_LBI_ICON | TF_LBI_TEXT | TF_LBI_STATUS);
    }

    return S_OK;
}

//+---------------------------------------------------------------------------
//
// GetIcon
//
//----------------------------------------------------------------------------

STDAPI CLangBarItemButton::GetIcon(HICON* phIcon)
{
    if (phIcon == NULL)
        return E_INVALIDARG;

    UINT uIconId = 0;

    if (_pTextService != NULL)
    {
        InputMode mode = _pTextService->GetInputMode();
        switch (mode)
        {
        case INPUTMODE_HIRAGANA:
            uIconId = IDI_MODE_HIRAGANA;      // �u���v�A�C�R��
            break;
        case INPUTMODE_ALPHANUMERIC:
            uIconId = IDI_MODE_ALPHANUMERIC;  // �uA�v�A�C�R��
            break;
        default:
            uIconId = IDI_TEXTSERVICE;        // �t�H�[���o�b�N
            break;
        }
    }
    else
    {
        uIconId = IDI_TEXTSERVICE;
    }

    *phIcon = (HICON)LoadImage(g_hInst,
        MAKEINTRESOURCE(uIconId),
        IMAGE_ICON,
        16,
        16,
        0);

    return (*phIcon != NULL) ? S_OK : E_FAIL;
}

//+---------------------------------------------------------------------------
//
// GetText
//
//----------------------------------------------------------------------------

STDAPI CLangBarItemButton::GetText(BSTR* pbstrText)
{
    if (pbstrText == NULL)
        return E_INVALIDARG;

    const WCHAR* pszText = NULL;

    if (_pTextService != NULL)
    {
        InputMode mode = _pTextService->GetInputMode();
        if (mode == INPUTMODE_HIRAGANA)
        {
            pszText = L"��";
        }
        else
        {
            pszText = L"A";
        }
    }
    else
    {
        pszText = LANGBAR_ITEM_DESC;
    }

    *pbstrText = SysAllocString(pszText);

    return (*pbstrText == NULL) ? E_OUTOFMEMORY : S_OK;
}

//+---------------------------------------------------------------------------
//
// AdviseSink
//
//----------------------------------------------------------------------------

STDAPI CLangBarItemButton::AdviseSink(REFIID riid, IUnknown* punk, DWORD* pdwCookie)
{
    //
    // We allow only ITfLangBarItemSink interface.
    //
    if (!IsEqualIID(IID_ITfLangBarItemSink, riid))
        return CONNECT_E_CANNOTCONNECT;

    //
    // We support only one sink once.
    //
    if (_pLangBarItemSink != NULL)
        return CONNECT_E_ADVISELIMIT;

    //
    // Query the ITfLangBarItemSink interface and store it into _pLangBarItemSink.
    //
    if (punk->QueryInterface(IID_ITfLangBarItemSink, (void**)&_pLangBarItemSink) != S_OK)
    {
        _pLangBarItemSink = NULL;
        return E_NOINTERFACE;
    }

    //
    // return our cookie.
    //
    *pdwCookie = TEXTSERVICE_LANGBARITEMSINK_COOKIE;
    return S_OK;
}

//+---------------------------------------------------------------------------
//
// UnadviseSink
//
//----------------------------------------------------------------------------

STDAPI CLangBarItemButton::UnadviseSink(DWORD dwCookie)
{
    //
    // Check the given cookie.
    //
    if (dwCookie != TEXTSERVICE_LANGBARITEMSINK_COOKIE)
        return CONNECT_E_NOCONNECTION;

    //
    // If there is no connected sink, we just fail.
    //
    if (_pLangBarItemSink == NULL)
        return CONNECT_E_NOCONNECTION;

    _pLangBarItemSink->Release();
    _pLangBarItemSink = NULL;

    return S_OK;
}

//+---------------------------------------------------------------------------
//
// _InitLanguageBar
//
//----------------------------------------------------------------------------

BOOL CTextService::_InitLanguageBar()
{
    ITfLangBarItemMgr* pLangBarItemMgr;
    BOOL fRet;

    if (_pThreadMgr->QueryInterface(IID_ITfLangBarItemMgr, (void**)&pLangBarItemMgr) != S_OK)
        return FALSE;

    fRet = FALSE;

    if ((_pLangBarItem = new CLangBarItemButton(this)) == NULL)
        goto Exit;

    if (pLangBarItemMgr->AddItem(_pLangBarItem) != S_OK)
    {
        _pLangBarItem->Release();
        _pLangBarItem = NULL;
        goto Exit;
    }

    fRet = TRUE;

Exit:
    pLangBarItemMgr->Release();
    return fRet;
}

//+---------------------------------------------------------------------------
//
// _UninitLanguageBar
//
//----------------------------------------------------------------------------

void CTextService::_UninitLanguageBar()
{
    ITfLangBarItemMgr* pLangBarItemMgr;

    if (_pLangBarItem == NULL)
        return;

    if (_pThreadMgr->QueryInterface(IID_ITfLangBarItemMgr, (void**)&pLangBarItemMgr) == S_OK)
    {
        pLangBarItemMgr->RemoveItem(_pLangBarItem);
        pLangBarItemMgr->Release();
    }

    _pLangBarItem->Release();
    _pLangBarItem = NULL;
}
