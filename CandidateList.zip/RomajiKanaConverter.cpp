// RomajiKanaConverter.cpp
#include "RomajiKanaConverter.h"

namespace {

    // Kotlin �� getDefaultMapData �Ɠ������e�̃e�[�u��
    std::unordered_map<std::wstring, RomajiKanaConverter::MapEntry> CreateDefaultMap()
    {
        using Entry = RomajiKanaConverter::MapEntry;
        std::unordered_map<std::wstring, Entry> m;

        // punctuation / symbols
        m.emplace(L"-", Entry{ L"�[", 1 });
        m.emplace(L"~", Entry{ L"?", 1 });
        m.emplace(L".", Entry{ L"�B", 1 });
        m.emplace(L",", Entry{ L"�A", 1 });
        m.emplace(L"z/", Entry{ L"�E", 2 });
        m.emplace(L"z.", Entry{ L"�c", 2 });
        m.emplace(L"z,", Entry{ L"�d", 2 });
        m.emplace(L"zh", Entry{ L"��", 2 });
        m.emplace(L"zj", Entry{ L"��", 2 });
        m.emplace(L"zk", Entry{ L"��", 2 });
        m.emplace(L"zl", Entry{ L"��", 2 });
        m.emplace(L"z-", Entry{ L"?", 2 });
        m.emplace(L"z[", Entry{ L"�w", 2 });
        m.emplace(L"z]", Entry{ L"�x", 2 });
        m.emplace(L"[", Entry{ L"�u", 1 });
        m.emplace(L"]", Entry{ L"�v", 1 });

        // v-row
        m.emplace(L"va", Entry{ L"?��", 2 });
        m.emplace(L"vi", Entry{ L"?��", 2 });
        m.emplace(L"vu", Entry{ L"?",   2 });
        m.emplace(L"ve", Entry{ L"?��", 2 });
        m.emplace(L"vo", Entry{ L"?��", 2 });
        m.emplace(L"vya", Entry{ L"?��", 3 });
        m.emplace(L"vyi", Entry{ L"?��", 3 });
        m.emplace(L"vyu", Entry{ L"?��", 3 });
        m.emplace(L"vye", Entry{ L"?��", 3 });
        m.emplace(L"vyo", Entry{ L"?��", 3 });

        // gemination (small tsu + consonant)
        m.emplace(L"qq", Entry{ L"��", 2 });
        m.emplace(L"vv", Entry{ L"��", 2 });
        m.emplace(L"ll", Entry{ L"��", 2 });
        m.emplace(L"xx", Entry{ L"��", 2 });
        m.emplace(L"kk", Entry{ L"��", 2 });
        m.emplace(L"gg", Entry{ L"��", 2 });
        m.emplace(L"ss", Entry{ L"��", 2 });
        m.emplace(L"zz", Entry{ L"��", 2 });
        m.emplace(L"jj", Entry{ L"��", 2 });
        m.emplace(L"tt", Entry{ L"��", 2 });
        m.emplace(L"tch", Entry{ L"��", 3 });
        m.emplace(L"dd", Entry{ L"��", 2 });
        m.emplace(L"hh", Entry{ L"��", 2 });
        m.emplace(L"ff", Entry{ L"��", 2 });
        m.emplace(L"bb", Entry{ L"��", 2 });
        m.emplace(L"pp", Entry{ L"��", 2 });
        m.emplace(L"mm", Entry{ L"��", 2 });
        m.emplace(L"yy", Entry{ L"��", 2 });
        m.emplace(L"rr", Entry{ L"��", 2 });
        m.emplace(L"ww", Entry{ L"��", 2 });
        m.emplace(L"www", Entry{ L"www", 3 });
        m.emplace(L"cc", Entry{ L"��", 2 });

        // k-row youon
        m.emplace(L"kya", Entry{ L"����", 3 });
        m.emplace(L"kyi", Entry{ L"����", 3 });
        m.emplace(L"kyu", Entry{ L"����", 3 });
        m.emplace(L"kye", Entry{ L"����", 3 });
        m.emplace(L"kyo", Entry{ L"����", 3 });

        // g-row youon
        m.emplace(L"gya", Entry{ L"����", 3 });
        m.emplace(L"gyi", Entry{ L"����", 3 });
        m.emplace(L"gyu", Entry{ L"����", 3 });
        m.emplace(L"gye", Entry{ L"����", 3 });
        m.emplace(L"gyo", Entry{ L"����", 3 });

        // s-row
        m.emplace(L"sya", Entry{ L"����", 3 });
        m.emplace(L"syi", Entry{ L"����", 3 });
        m.emplace(L"syu", Entry{ L"����", 3 });
        m.emplace(L"sye", Entry{ L"����", 3 });
        m.emplace(L"syo", Entry{ L"����", 3 });
        m.emplace(L"sha", Entry{ L"����", 3 });
        m.emplace(L"shi", Entry{ L"��",   3 });
        m.emplace(L"shu", Entry{ L"����", 3 });
        m.emplace(L"she", Entry{ L"����", 3 });
        m.emplace(L"sho", Entry{ L"����", 3 });

        // n-row
        m.emplace(L"na", Entry{ L"��", 2 });
        m.emplace(L"ni", Entry{ L"��", 2 });
        m.emplace(L"nu", Entry{ L"��", 2 });
        m.emplace(L"ne", Entry{ L"��", 2 });
        m.emplace(L"no", Entry{ L"��", 2 });

        // k-row
        m.emplace(L"ca", Entry{ L"��", 2 });
        m.emplace(L"ka", Entry{ L"��", 2 });
        m.emplace(L"ki", Entry{ L"��", 2 });
        m.emplace(L"ku", Entry{ L"��", 2 });
        m.emplace(L"ke", Entry{ L"��", 2 });
        m.emplace(L"ko", Entry{ L"��", 2 });

        // s-row basic
        m.emplace(L"sa", Entry{ L"��", 2 });
        m.emplace(L"si", Entry{ L"��", 2 });
        m.emplace(L"su", Entry{ L"��", 2 });
        m.emplace(L"se", Entry{ L"��", 2 });
        m.emplace(L"so", Entry{ L"��", 2 });

        // g-row basic
        m.emplace(L"ga", Entry{ L"��", 2 });
        m.emplace(L"gi", Entry{ L"��", 2 });
        m.emplace(L"gu", Entry{ L"��", 2 });
        m.emplace(L"ge", Entry{ L"��", 2 });
        m.emplace(L"go", Entry{ L"��", 2 });

        // z-row
        m.emplace(L"zya", Entry{ L"����", 3 });
        m.emplace(L"zyi", Entry{ L"����", 3 });
        m.emplace(L"zyu", Entry{ L"����", 3 });
        m.emplace(L"zye", Entry{ L"����", 3 });
        m.emplace(L"zyo", Entry{ L"����", 3 });
        m.emplace(L"za", Entry{ L"��",  2 });
        m.emplace(L"zi", Entry{ L"��",  2 });
        m.emplace(L"zu", Entry{ L"��",  2 });
        m.emplace(L"ze", Entry{ L"��",  2 });
        m.emplace(L"zo", Entry{ L"��",  2 });

        m.emplace(L"jya", Entry{ L"����", 3 });
        m.emplace(L"jyi", Entry{ L"����", 3 });
        m.emplace(L"jyu", Entry{ L"����", 3 });
        m.emplace(L"jye", Entry{ L"����", 3 });
        m.emplace(L"jyo", Entry{ L"����", 3 });
        m.emplace(L"ja", Entry{ L"����", 2 });
        m.emplace(L"ji", Entry{ L"��",   2 });
        m.emplace(L"ju", Entry{ L"����", 2 });
        m.emplace(L"je", Entry{ L"����", 2 });
        m.emplace(L"jo", Entry{ L"����", 2 });

        // t-row youon & variants
        m.emplace(L"tya", Entry{ L"����", 3 });
        m.emplace(L"tyi", Entry{ L"����", 3 });
        m.emplace(L"tyu", Entry{ L"����", 3 });
        m.emplace(L"tye", Entry{ L"����", 3 });
        m.emplace(L"tyo", Entry{ L"����", 3 });
        m.emplace(L"cha", Entry{ L"����", 3 });
        m.emplace(L"chi", Entry{ L"��",   3 });
        m.emplace(L"chu", Entry{ L"����", 3 });
        m.emplace(L"che", Entry{ L"����", 3 });
        m.emplace(L"cho", Entry{ L"����", 3 });
        m.emplace(L"cya", Entry{ L"����", 3 });
        m.emplace(L"cyi", Entry{ L"����", 3 });
        m.emplace(L"cyu", Entry{ L"����", 3 });
        m.emplace(L"cye", Entry{ L"����", 3 });
        m.emplace(L"cyo", Entry{ L"����", 3 });

        m.emplace(L"ta", Entry{ L"��", 2 });
        m.emplace(L"ti", Entry{ L"��", 2 });
        m.emplace(L"tu", Entry{ L"��", 2 });
        m.emplace(L"tsu", Entry{ L"��", 3 });
        m.emplace(L"te", Entry{ L"��", 2 });
        m.emplace(L"to", Entry{ L"��", 2 });

        // d-row youon & variants
        m.emplace(L"dya", Entry{ L"����", 3 });
        m.emplace(L"dyi", Entry{ L"����", 3 });
        m.emplace(L"dyu", Entry{ L"����", 3 });
        m.emplace(L"dye", Entry{ L"����", 3 });
        m.emplace(L"dyo", Entry{ L"����", 3 });
        m.emplace(L"da", Entry{ L"��",   2 });
        m.emplace(L"di", Entry{ L"��",   2 });
        m.emplace(L"du", Entry{ L"��",   2 });
        m.emplace(L"de", Entry{ L"��",   2 });
        m.emplace(L"do", Entry{ L"��",   2 });

        // de-y variants
        m.emplace(L"dha", Entry{ L"�ł�", 3 });
        m.emplace(L"dhi", Entry{ L"�ł�", 3 });
        m.emplace(L"d'i", Entry{ L"�ł�", 3 });
        m.emplace(L"dhu", Entry{ L"�ł�", 3 });
        m.emplace(L"dhe", Entry{ L"�ł�", 3 });
        m.emplace(L"dho", Entry{ L"�ł�", 3 });
        m.emplace(L"d'yu", Entry{ L"�ł�", 4 });

        // t-h variants
        m.emplace(L"tha", Entry{ L"�Ă�", 3 });
        m.emplace(L"thi", Entry{ L"�Ă�", 3 });
        m.emplace(L"t'i", Entry{ L"�Ă�", 3 });
        m.emplace(L"thu", Entry{ L"�Ă�", 3 });
        m.emplace(L"the", Entry{ L"�Ă�", 3 });
        m.emplace(L"tho", Entry{ L"�Ă�", 3 });
        m.emplace(L"t'yu", Entry{ L"�Ă�", 4 });

        // t-w variants
        m.emplace(L"twa", Entry{ L"�Ƃ�", 3 });
        m.emplace(L"twi", Entry{ L"�Ƃ�", 3 });
        m.emplace(L"twu", Entry{ L"�Ƃ�", 3 });
        m.emplace(L"twe", Entry{ L"�Ƃ�", 3 });
        m.emplace(L"two", Entry{ L"�Ƃ�", 3 });
        m.emplace(L"t'u", Entry{ L"�Ƃ�", 3 });

        // d-w variants
        m.emplace(L"dwa", Entry{ L"�ǂ�", 3 });
        m.emplace(L"dwi", Entry{ L"�ǂ�", 3 });
        m.emplace(L"dwu", Entry{ L"�ǂ�", 3 });
        m.emplace(L"dwe", Entry{ L"�ǂ�", 3 });
        m.emplace(L"dwo", Entry{ L"�ǂ�", 3 });
        m.emplace(L"d'u", Entry{ L"�ǂ�", 3 });

        // n-row youon & n variants
        m.emplace(L"nya", Entry{ L"�ɂ�", 3 });
        m.emplace(L"nyi", Entry{ L"�ɂ�", 3 });
        m.emplace(L"nyu", Entry{ L"�ɂ�", 3 });
        m.emplace(L"nye", Entry{ L"�ɂ�", 3 });
        m.emplace(L"nyo", Entry{ L"�ɂ�", 3 });
        m.emplace(L"nn", Entry{ L"��",   2 });
        m.emplace(L"xn", Entry{ L"��",   2 });

        // h-row youon & variants
        m.emplace(L"hya", Entry{ L"�Ђ�", 3 });
        m.emplace(L"hyi", Entry{ L"�Ђ�", 3 });
        m.emplace(L"hyu", Entry{ L"�Ђ�", 3 });
        m.emplace(L"hye", Entry{ L"�Ђ�", 3 });
        m.emplace(L"hyo", Entry{ L"�Ђ�", 3 });
        m.emplace(L"ha", Entry{ L"��",   2 });
        m.emplace(L"hi", Entry{ L"��",   2 });
        m.emplace(L"hu", Entry{ L"��",   2 });
        m.emplace(L"fu", Entry{ L"��",   2 });
        m.emplace(L"he", Entry{ L"��",   2 });
        m.emplace(L"ho", Entry{ L"��",   2 });

        // b-row youon
        m.emplace(L"bya", Entry{ L"�т�", 3 });
        m.emplace(L"byi", Entry{ L"�т�", 3 });
        m.emplace(L"byu", Entry{ L"�т�", 3 });
        m.emplace(L"bye", Entry{ L"�т�", 3 });
        m.emplace(L"byo", Entry{ L"�т�", 3 });
        m.emplace(L"ba", Entry{ L"��",   2 });
        m.emplace(L"bi", Entry{ L"��",   2 });
        m.emplace(L"bu", Entry{ L"��",   2 });
        m.emplace(L"be", Entry{ L"��",   2 });
        m.emplace(L"bo", Entry{ L"��",   2 });

        // p-row youon
        m.emplace(L"pya", Entry{ L"�҂�", 3 });
        m.emplace(L"pyi", Entry{ L"�҂�", 3 });
        m.emplace(L"pyu", Entry{ L"�҂�", 3 });
        m.emplace(L"pye", Entry{ L"�҂�", 3 });
        m.emplace(L"pyo", Entry{ L"�҂�", 3 });
        m.emplace(L"pa", Entry{ L"��",   2 });
        m.emplace(L"pi", Entry{ L"��",   2 });
        m.emplace(L"pu", Entry{ L"��",   2 });
        m.emplace(L"pe", Entry{ L"��",   2 });
        m.emplace(L"po", Entry{ L"��",   2 });

        // f-variants & youon
        m.emplace(L"fa", Entry{ L"�ӂ�", 2 });
        m.emplace(L"fi", Entry{ L"�ӂ�", 2 });
        m.emplace(L"fe", Entry{ L"�ӂ�", 2 });
        m.emplace(L"fo", Entry{ L"�ӂ�", 2 });
        m.emplace(L"fya", Entry{ L"�ӂ�", 3 });
        m.emplace(L"fyu", Entry{ L"�ӂ�", 3 });
        m.emplace(L"fyo", Entry{ L"�ӂ�", 3 });
        m.emplace(L"hwa", Entry{ L"�ӂ�", 3 });
        m.emplace(L"hwi", Entry{ L"�ӂ�", 3 });
        m.emplace(L"hwe", Entry{ L"�ӂ�", 3 });
        m.emplace(L"hwo", Entry{ L"�ӂ�", 3 });
        m.emplace(L"hwyu", Entry{ L"�ӂ�", 4 });

        // m-row youon
        m.emplace(L"mya", Entry{ L"�݂�", 3 });
        m.emplace(L"myi", Entry{ L"�݂�", 3 });
        m.emplace(L"myu", Entry{ L"�݂�", 3 });
        m.emplace(L"mye", Entry{ L"�݂�", 3 });
        m.emplace(L"myo", Entry{ L"�݂�", 3 });
        m.emplace(L"ma", Entry{ L"��",   2 });
        m.emplace(L"mi", Entry{ L"��",   2 });
        m.emplace(L"mu", Entry{ L"��",   2 });
        m.emplace(L"me", Entry{ L"��",   2 });
        m.emplace(L"mo", Entry{ L"��",   2 });

        // y-row
        m.emplace(L"xya", Entry{ L"��",   3 });
        m.emplace(L"lya", Entry{ L"��",   3 });
        m.emplace(L"ya", Entry{ L"��",   2 });
        m.emplace(L"wyi", Entry{ L"��",   3 });
        m.emplace(L"xyu", Entry{ L"��",   3 });
        m.emplace(L"lyu", Entry{ L"��",   3 });
        m.emplace(L"yu", Entry{ L"��",   2 });
        m.emplace(L"wye", Entry{ L"��",   3 });
        m.emplace(L"xyo", Entry{ L"��",   3 });
        m.emplace(L"lyo", Entry{ L"��",   3 });
        m.emplace(L"yo", Entry{ L"��",   2 });

        // r-row youon
        m.emplace(L"rya", Entry{ L"���", 3 });
        m.emplace(L"ryi", Entry{ L"�股", 3 });
        m.emplace(L"ryu", Entry{ L"���", 3 });
        m.emplace(L"rye", Entry{ L"�肥", 3 });
        m.emplace(L"ryo", Entry{ L"���", 3 });
        m.emplace(L"ra", Entry{ L"��",   2 });
        m.emplace(L"ri", Entry{ L"��",   2 });
        m.emplace(L"ru", Entry{ L"��",   2 });
        m.emplace(L"re", Entry{ L"��",   2 });
        m.emplace(L"ro", Entry{ L"��",   2 });

        // w-row & variants
        m.emplace(L"xwa", Entry{ L"��",   3 });
        m.emplace(L"lwa", Entry{ L"��",   3 });
        m.emplace(L"wa", Entry{ L"��",   2 });
        m.emplace(L"wi", Entry{ L"����", 2 });
        m.emplace(L"we", Entry{ L"����", 2 });
        m.emplace(L"wo", Entry{ L"��",   2 });
        m.emplace(L"wha", Entry{ L"����", 3 });
        m.emplace(L"whi", Entry{ L"����", 3 });
        m.emplace(L"whu", Entry{ L"��",   3 });
        m.emplace(L"whe", Entry{ L"����", 3 });
        m.emplace(L"who", Entry{ L"����", 3 });

        // basic vowels
        m.emplace(L"a", Entry{ L"��", 1 });
        m.emplace(L"i", Entry{ L"��", 1 });
        m.emplace(L"u", Entry{ L"��", 1 });
        m.emplace(L"wu", Entry{ L"��", 2 });
        m.emplace(L"e", Entry{ L"��", 1 });
        m.emplace(L"o", Entry{ L"��", 1 });

        // small vowels
        m.emplace(L"xa", Entry{ L"��", 2 });
        m.emplace(L"xi", Entry{ L"��", 2 });
        m.emplace(L"xu", Entry{ L"��", 2 });
        m.emplace(L"xe", Entry{ L"��", 2 });
        m.emplace(L"xo", Entry{ L"��", 2 });
        m.emplace(L"la", Entry{ L"��", 2 });
        m.emplace(L"li", Entry{ L"��", 2 });
        m.emplace(L"lu", Entry{ L"��", 2 });
        m.emplace(L"le", Entry{ L"��", 2 });
        m.emplace(L"lo", Entry{ L"��", 2 });
        m.emplace(L"lyi", Entry{ L"��", 3 });
        m.emplace(L"xyi", Entry{ L"��", 3 });
        m.emplace(L"lye", Entry{ L"��", 3 });
        m.emplace(L"xye", Entry{ L"��", 3 });
        m.emplace(L"ye", Entry{ L"����", 2 });

        // x-row small kana
        m.emplace(L"xka", Entry{ L"��", 3 });
        m.emplace(L"xke", Entry{ L"��", 3 });
        m.emplace(L"lka", Entry{ L"��", 3 });
        m.emplace(L"lke", Entry{ L"��", 3 });

        // qa/ku-variants
        m.emplace(L"qa", Entry{ L"����", 2 });
        m.emplace(L"qi", Entry{ L"����", 2 });
        m.emplace(L"qu", Entry{ L"��",   2 });
        m.emplace(L"qe", Entry{ L"����", 2 });
        m.emplace(L"qo", Entry{ L"����", 2 });

        // kw-variants
        m.emplace(L"kwa", Entry{ L"����", 3 });
        m.emplace(L"kwi", Entry{ L"����", 3 });
        m.emplace(L"kwu", Entry{ L"����", 3 });
        m.emplace(L"kwe", Entry{ L"����", 3 });
        m.emplace(L"kwo", Entry{ L"����", 3 });

        // gw-variants
        m.emplace(L"gwa", Entry{ L"����", 3 });
        m.emplace(L"gwi", Entry{ L"����", 3 });
        m.emplace(L"gwu", Entry{ L"����", 3 });
        m.emplace(L"gwe", Entry{ L"����", 3 });
        m.emplace(L"gwo", Entry{ L"����", 3 });

        // sw-variants
        m.emplace(L"swa", Entry{ L"����", 3 });
        m.emplace(L"swi", Entry{ L"����", 3 });
        m.emplace(L"swu", Entry{ L"����", 3 });
        m.emplace(L"swe", Entry{ L"����", 3 });
        m.emplace(L"swo", Entry{ L"����", 3 });

        // zw-variants
        m.emplace(L"zwa", Entry{ L"����", 3 });
        m.emplace(L"zwi", Entry{ L"����", 3 });
        m.emplace(L"zwu", Entry{ L"����", 3 });
        m.emplace(L"zwe", Entry{ L"����", 3 });
        m.emplace(L"zwo", Entry{ L"����", 3 });

        // xtsu / ltsu variants
        m.emplace(L"xtu", Entry{ L"��", 3 });
        m.emplace(L"xtsu", Entry{ L"��", 4 });
        m.emplace(L"ltu", Entry{ L"��", 3 });
        m.emplace(L"ltsu", Entry{ L"��", 4 });

        return m;
    }

} // anonymous namespace

RomajiKanaConverter::RomajiKanaConverter()
{
    m_romajiToKana = CreateDefaultMap();

    m_maxKeyLength = 1;
    for (const auto& kv : m_romajiToKana)
    {
        int len = static_cast<int>(kv.first.size());
        if (len > m_maxKeyLength)
            m_maxKeyLength = len;
    }
}

wchar_t RomajiKanaConverter::ToHalfWidth(wchar_t ch)
{
    // �S�p�p�� �� ���p�p���i�������ɑ�����j
    if (ch >= L'��' && ch <= L'��')
    {
        return L'a' + (ch - L'��');
    }
    if (ch >= L'�`' && ch <= L'�y')
    {
        return L'a' + (ch - L'�`');
    }

    // �S�p���� �� ���p����
    if (ch >= L'�O' && ch <= L'�X')
    {
        return L'0' + (ch - L'�O');
    }

    // �S�p [ ] �� ���p
    if (ch == L'�m') return L'[';
    if (ch == L'�n') return L']';

    // ���̑��͂��̂܂�
    return ch;
}

std::wstring RomajiKanaConverter::FullWidthToHalfWidth(const std::wstring& src)
{
    std::wstring dst;
    dst.reserve(src.size());
    for (wchar_t ch : src)
    {
        dst.push_back(ToHalfWidth(ch));
    }
    return dst;
}

// RawText(�S�p) -> SurfaceText(����) �ɕϊ�
std::wstring RomajiKanaConverter::ConvertFromRaw(const std::wstring& raw) const
{
    // �܂��S�p�p���𔼊p�ɐ��K��
    std::wstring text = FullWidthToHalfWidth(raw);

    std::wstring result;
    size_t i = 0;

    while (i < text.size())
    {
        wchar_t current = text[i];

        // 1. '[' / ']' �͕ϊ��������̂܂�
        if (current == L'[' || current == L']')
        {
            result.push_back(current);
            ++i;
            continue;
        }

        // 2. �����i���j�̔���: �q���̏d�ˁinn �������j
        if (i + 1 < text.size() &&
            current == text[i + 1])
        {
            const std::wstring sokuonConsonants = L"kstcpbdfghljmqrvwxyz";
            if (sokuonConsonants.find(current) != std::wstring::npos)
            {
                result.push_back(L'��');
                ++i; // 1������������
                continue;
            }
        }

        // 3. �un�v�̓��ʃ��[��
        if (current == L'n' && i + 1 < text.size())
        {
            wchar_t next = text[i + 1];
            const std::wstring vowels = L"aiueoyn";
            if (vowels.find(next) == std::wstring::npos)
            {
                result.push_back(L'��');
                ++i;
                continue;
            }
        }

        // 4. �Œ���v�� romajiToKana ������
        bool matched = false;
        for (int len = m_maxKeyLength; len >= 1; --len)
        {
            if (i + len > text.size())
                continue;

            std::wstring segment = text.substr(i, len);
            auto it = m_romajiToKana.find(segment);
            if (it != m_romajiToKana.end())
            {
                const MapEntry& entry = it->second;
                result.append(entry.kana);
                i += entry.consume;
                matched = true;
                break;
            }
        }

        // 5. �}�b�`���Ȃ����������͂��̂܂�
        if (!matched)
        {
            result.push_back(text[i]);
            ++i;
        }
    }

    return result;
}
